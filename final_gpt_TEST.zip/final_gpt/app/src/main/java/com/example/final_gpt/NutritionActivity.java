package com.example.final_gpt;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.List;

public class NutritionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition);

        TextView nutritionText = findViewById(R.id.nutritionText);
        Button backButton = findViewById(R.id.backButton);

        // selectedMenu 정보를 Intent로부터 가져와서 영양성분 요청
        String selectedMenu = getIntent().getStringExtra("selectedMenu");
        getNutritionForMenu(selectedMenu);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 뒤로가기 버튼을 클릭하면 현재 Activity를 종료
            }
        });
    }

    private void getNutritionForMenu(String menu) {
        String nutritionPrompt = menu + " 영양성분 알려줘 fatscrect사이트를 참조해서 (칼로리, 탄수화물, 단백질, 지방, 나트륨, 콜레스테롤)";
        List<ChatbotRequest.Message> messages = new ArrayList<>();
        messages.add(new ChatbotRequest.Message("user", nutritionPrompt));

        ChatbotRequest request = new ChatbotRequest("gpt-3.5-turbo", messages);
        ApiService apiService = NetworkClient.getApiService();
        Call<ChatbotResponse> call = apiService.getChatbotResponse(request);

        call.enqueue(new Callback<ChatbotResponse>() {
            @Override
            public void onResponse(Call<ChatbotResponse> call, Response<ChatbotResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String chatbotReply = response.body().getChoices().get(0).getMessage().getContent();
                    TextView nutritionText = findViewById(R.id.nutritionText);
                    nutritionText.setText(chatbotReply);
                } else {
                    TextView nutritionText = findViewById(R.id.nutritionText);
                    nutritionText.setText("영양성분 정보를 가져오지 못했습니다.");
                    Log.e("NutritionActivity", "Response code: " + response.code());
                    Log.e("NutritionActivity", "Response message: " + response.message());
                    try {
                        Log.e("NutritionActivity", "Response error body: " + response.errorBody().string());
                    } catch (Exception e) {
                        Log.e("NutritionActivity", "Error reading error body", e);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChatbotResponse> call, Throwable t) {
                Log.e("NutritionActivity", "Error calling API", t);
                TextView nutritionText = findViewById(R.id.nutritionText);
                nutritionText.setText("영양성분 정보를 가져오는데 실패했습니다: " + t.getMessage());
            }
        });
    }
}
