package com.example.final_gpt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText inputText;
    private TextView outputText;
    private Button sendButton;
    private Button menuRecommendButton;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        outputText = findViewById(R.id.outputText);
        sendButton = findViewById(R.id.sendButton);
        menuRecommendButton = findViewById(R.id.menuRecommendButton);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = inputText.getText().toString();
                if (!text.isEmpty()) {
                    sendChatbotRequest(text);
                }
            }
        });

        menuRecommendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MenuRecommendActivity.class);
                startActivity(intent);
            }
        });


    }

    private void sendChatbotRequest(String text) {
        progressBar.setVisibility(View.VISIBLE);
        outputText.setText("");

        List<ChatbotRequest.Message> messages = new ArrayList<>();
        messages.add(new ChatbotRequest.Message("user", text));

        ChatbotRequest request = new ChatbotRequest("gpt-3.5-turbo", messages);
        ApiService apiService = NetworkClient.getApiService();
        Call<ChatbotResponse> call = apiService.getChatbotResponse(request);

        call.enqueue(new Callback<ChatbotResponse>() {
            @Override
            public void onResponse(Call<ChatbotResponse> call, Response<ChatbotResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    String chatbotReply = response.body().getChoices().get(0).getMessage().getContent();
                    outputText.setText(chatbotReply);
                } else {
                    outputText.setText("응답을 가져오지 못했습니다. 다시 시도해 주세요.");
                }
            }

            @Override
            public void onFailure(Call<ChatbotResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                outputText.setText("오류 발생: " + t.getMessage());
            }
        });
    }
}
