package com.example.final_gpt;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.youtube.YouTube;

public class YouTubeApi {

    private static YouTube youtubeService;

    public static YouTube getService() {
        if (youtubeService == null) {
            try {
                youtubeService = new YouTube.Builder(GoogleNetHttpTransport.newTrustedTransport(), GsonFactory.getDefaultInstance(), null)
                        .setApplicationName("final_gpt")
                        .build();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return youtubeService;
    }
}
