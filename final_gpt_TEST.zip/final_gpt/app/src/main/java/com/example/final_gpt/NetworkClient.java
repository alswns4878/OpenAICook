package com.example.final_gpt;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

public class NetworkClient {
    private static Retrofit openAiRetrofit = null;
    private static Retrofit fatSecretRetrofit = null;

    public static ApiService getApiService() {
        if (openAiRetrofit == null) {
            openAiRetrofit = new Retrofit.Builder()
                    .baseUrl("https://api.openai.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return openAiRetrofit.create(ApiService.class);
    }


}
