package com.example.final_gpt;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class YoutubeActivity extends AppCompatActivity {

    private static final String TAG = "YoutubeActivity";
    private static final String YOUTUBE_API_KEY = "AIzaSyBINevGUTdZ2tvBvJ6AXOtZ_TLraWaD91E"; // Replace with your actual YouTube API key
    private static final long NUMBER_OF_VIDEOS_RETURNED = 10;

    private RecyclerView recyclerView;
    private YouTubeRecyclerViewAdapter adapter;
    private List<SearchResult> searchResults = new ArrayList<>();
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new YouTubeRecyclerViewAdapter(searchResults);
        recyclerView.setAdapter(adapter);

        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        Intent intent = getIntent();
        String selectedMenu = intent.getStringExtra("selectedMenu");

        if (selectedMenu != null) {
            searchYoutubeVideos(selectedMenu);
        } else {
            Toast.makeText(this, "메뉴가 선택되지 않았습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void searchYoutubeVideos(String query) {
        new Thread(() -> {
            try {
                YouTube youtubeService = YouTubeApi.getService();
                YouTube.Search.List search = youtubeService.search().list("id,snippet");

                search.setKey(YOUTUBE_API_KEY);
                search.setQ(query + " 레시피");
                search.setType("video");
                search.setMaxResults(NUMBER_OF_VIDEOS_RETURNED);

                SearchListResponse searchResponse = search.execute();
                searchResults = searchResponse.getItems();

                runOnUiThread(() -> adapter.updateData(searchResults));

            } catch (IOException e) {
                Log.e(TAG, "Error searching YouTube videos", e);
            }
        }).start();
    }
}
