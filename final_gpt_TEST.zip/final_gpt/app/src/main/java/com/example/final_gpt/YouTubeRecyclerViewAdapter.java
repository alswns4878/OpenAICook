package com.example.final_gpt;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.Thumbnail;

import java.util.List;

public class YouTubeRecyclerViewAdapter extends RecyclerView.Adapter<YouTubeRecyclerViewAdapter.ViewHolder> {

    private List<SearchResult> searchResults;

    public YouTubeRecyclerViewAdapter(List<SearchResult> searchResults) {
        this.searchResults = searchResults;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.youtube_video_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SearchResult searchResult = searchResults.get(position);

        holder.title.setText(searchResult.getSnippet().getTitle());
        holder.description.setText(searchResult.getSnippet().getDescription());
        Thumbnail thumbnail = searchResult.getSnippet().getThumbnails().getDefault();
        Glide.with(holder.itemView.getContext()).load(thumbnail.getUrl()).into(holder.thumbnail);

        holder.itemView.setOnClickListener(v -> {
            Context context = v.getContext();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + searchResult.getId().getVideoId()));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return searchResults.size();
    }

    public void updateData(List<SearchResult> newSearchResults) {
        searchResults = newSearchResults;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView description;
        public ImageView thumbnail;

        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.video_title);
            description = itemView.findViewById(R.id.video_description);
            thumbnail = itemView.findViewById(R.id.video_thumbnail);
        }
    }
}
