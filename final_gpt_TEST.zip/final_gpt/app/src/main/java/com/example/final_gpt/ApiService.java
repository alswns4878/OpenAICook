package com.example.final_gpt;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiService {
    @Headers({
            "Content-Type: application/json",
            "Authorization: Bearer sk-proj-OPJ65sgOn1032u1wOp7AT3BlbkFJ2zLGmI5tVmrAj1JReKlM"
    })
    @POST("v1/chat/completions") // Correct endpoint for chat models
    Call<ChatbotResponse> getChatbotResponse(@Body ChatbotRequest request);
}
