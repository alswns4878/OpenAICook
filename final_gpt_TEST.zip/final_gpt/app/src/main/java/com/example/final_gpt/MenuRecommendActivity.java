package com.example.final_gpt;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.List;

public class MenuRecommendActivity extends AppCompatActivity {
    private ListView menuListView;
    private TextView outputText;
    private ProgressBar progressBar;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_recommend);

        menuListView = findViewById(R.id.menuListView);
        outputText = findViewById(R.id.outputText);
        progressBar = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.imageView);
        progressBar.setVisibility(View.GONE);

        setupMenuOptionButtons();

        findViewById(R.id.backButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });

        findViewById(R.id.fridgeBasedButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showIngredientInputDialog();
            }
        });
    }

    private void setupMenuOptionButtons() {
        findViewById(R.id.koreanButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatbotMenuRequest("한식");
            }
        });

        findViewById(R.id.westernButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatbotMenuRequest("양식");
            }
        });

        findViewById(R.id.chineseButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatbotMenuRequest("중식");
            }
        });

        findViewById(R.id.japaneseButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatbotMenuRequest("일식");
            }
        });

        findViewById(R.id.othersButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatbotMenuRequest("기타");
            }
        });
    }

    private void showIngredientInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("재료 입력");

        final EditText input = new EditText(this);
        input.setHint("Enter ingredients");
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String ingredients = input.getText().toString().trim();
                if (!ingredients.isEmpty()) {
                    sendChatbotMenuRequest("재료 " + ingredients + "를 이용해 만들 수 있는");
                } else {
                    outputText.setText("입력된 재료가 없습니다.");
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void sendChatbotMenuRequest(String prompt) {
        progressBar.setVisibility(View.VISIBLE);
        outputText.setText("");

        String formattedPrompt = prompt + " 메뉴 추천해주고 리스트로 정리해서 10가지 보여줘";

        List<ChatbotRequest.Message> messages = new ArrayList<>();
        messages.add(new ChatbotRequest.Message("user", formattedPrompt));

        ChatbotRequest request = new ChatbotRequest("gpt-3.5-turbo", messages);
        ApiService apiService = NetworkClient.getApiService();
        Call<ChatbotResponse> call = apiService.getChatbotResponse(request);

        call.enqueue(new Callback<ChatbotResponse>() {
            @Override
            public void onResponse(Call<ChatbotResponse> call, Response<ChatbotResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    String chatbotReply = response.body().getChoices().get(0).getMessage().getContent();
                    displayMenuOptions(chatbotReply);
                } else {
                    outputText.setText("응답을 가져오지 못했습니다. 다시 시도해 주세요.");
                    Log.e("MenuRecommendActivity", "Response code: " + response.code());
                    Log.e("MenuRecommendActivity", "Response message: " + response.message());
                    try {
                        Log.e("MenuRecommendActivity", "Response error body: " + response.errorBody().string());
                    } catch (Exception e) {
                        Log.e("MenuRecommendActivity", "Error reading error body", e);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChatbotResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Log.e("MenuRecommendActivity", "Error calling API", t);
                outputText.setText("오류 발생: " + t.getMessage());
            }
        });
    }

    private void displayMenuOptions(String menuOptions) {
        String[] menuArray = menuOptions.split("\n"); // Assuming each menu is separated by a newline
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, menuArray);
        menuListView.setAdapter(adapter);
        menuListView.setVisibility(View.VISIBLE);

        menuListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedMenu = menuArray[position];
                Intent intent = new Intent(MenuRecommendActivity.this, RecipeActivity.class);
                intent.putExtra("selectedMenu", selectedMenu);
                startActivity(intent);
            }
        });
    }
}
