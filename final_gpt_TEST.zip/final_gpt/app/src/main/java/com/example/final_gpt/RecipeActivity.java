package com.example.final_gpt;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.CalendarContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class RecipeActivity extends AppCompatActivity {
    private TextView recipeText;
    private ProgressBar progressBar;
    private String selectedMenu;
    private Handler handler = new Handler();
    private boolean isLoading = false;

    private static final int REQUEST_CALENDAR_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        recipeText = findViewById(R.id.recipeText);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        selectedMenu = getIntent().getStringExtra("selectedMenu");
        if (selectedMenu == null) {
            Toast.makeText(this, "메뉴가 선택되지 않았습니다.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        findViewById(R.id.Menudecision).setOnClickListener(v -> showDecisionDialog());

        findViewById(R.id.nutritionButton).setOnClickListener(v -> {
            Intent intent = new Intent(RecipeActivity.this, NutritionActivity.class);
            intent.putExtra("selectedMenu", selectedMenu);  // selectedMenu를 전달
            startActivity(intent);
        });

        findViewById(R.id.YoutubeButton).setOnClickListener(v -> {
            Intent intent = new Intent(RecipeActivity.this, YoutubeActivity.class);
            intent.putExtra("selectedMenu", selectedMenu);  // selectedMenu를 전달
            startActivity(intent);
        });

        startLoadingAnimation();
        getRecipeForMenu(selectedMenu);

        checkAndRequestPermissions();
    }

    private void getRecipeForMenu(String menu) {
        progressBar.setVisibility(View.VISIBLE);
        isLoading = true;

        String prompt = menu + " 한국어로 만드는 방법 알려줘 초보자도 만들 수 있게 자세하게 레시피를 알려줘";

        List<ChatbotRequest.Message> messages = new ArrayList<>();
        messages.add(new ChatbotRequest.Message("user", prompt));

        ChatbotRequest request = new ChatbotRequest("gpt-3.5-turbo", messages);
        ApiService apiService = NetworkClient.getApiService();
        Call<ChatbotResponse> call = apiService.getChatbotResponse(request);

        call.enqueue(new Callback<ChatbotResponse>() {
            @Override
            public void onResponse(Call<ChatbotResponse> call, Response<ChatbotResponse> response) {
                progressBar.setVisibility(View.GONE);
                isLoading = false;
                if (response.isSuccessful() && response.body() != null) {
                    String chatbotReply = response.body().getChoices().get(0).getMessage().getContent();
                    recipeText.setText(chatbotReply);
                } else {
                    recipeText.setText("응답을 가져오지 못했습니다. 다시 시도해 주세요.");
                    Log.e("RecipeActivity", "Response code: " + response.code());
                    Log.e("RecipeActivity", "Response message: " + response.message());
                    try {
                        Log.e("RecipeActivity", "Response error body: " + response.errorBody().string());
                    } catch (Exception e) {
                        Log.e("RecipeActivity", "Error reading error body", e);
                    }
                }
            }

            @Override
            public void onFailure(Call<ChatbotResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Log.e("RecipeActivity", "Error calling API", t);
                recipeText.setText("오류 발생: " + t.getMessage());
            }
        });
    }

    private void showDecisionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("메뉴 결정 확인")
                .setMessage("선택하신 메뉴를 결정하시겠습니까?")
                .setPositiveButton("확인", (dialog, which) -> {
                    saveMenuDecision(selectedMenu);
                    checkCalendarPermissionAndAddEvent();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void saveMenuDecision(String menu) {
        SharedPreferences sharedPref = getSharedPreferences("MenuPreferences", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("selectedMenu", menu);
        editor.apply();
        Toast.makeText(RecipeActivity.this, "메뉴가 결정되었습니다.", Toast.LENGTH_SHORT).show();
    }

    private void checkCalendarPermissionAndAddEvent() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_CALENDAR, Manifest.permission.READ_CALENDAR}, REQUEST_CALENDAR_PERMISSION);
        } else {
            addEventToCalendar();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALENDAR_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                addEventToCalendar();
            } else {
                Toast.makeText(this, "캘린더 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addEventToCalendar() {
        SharedPreferences sharedPref = getSharedPreferences("MenuPreferences", Context.MODE_PRIVATE);
        String menu = sharedPref.getString("selectedMenu", null);
        if (menu == null) {
            Toast.makeText(this, "저장된 메뉴가 없습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        long calendarId = getPrimaryCalendarId();
        if (calendarId == -1) {
            Toast.makeText(this, "캘린더를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        long startMillis;
        long endMillis;

        Calendar beginTime = Calendar.getInstance();
        startMillis = beginTime.getTimeInMillis();

        Calendar endTime = Calendar.getInstance();
        endTime.add(Calendar.HOUR_OF_DAY, 1); // 종료 시간을 1시간 후로 설정
        endMillis = endTime.getTimeInMillis();

        ContentValues values = new ContentValues();
        values.put(CalendarContract.Events.DTSTART, startMillis);
        values.put(CalendarContract.Events.DTEND, endMillis);
        values.put(CalendarContract.Events.TITLE, "메뉴: " + menu);
        values.put(CalendarContract.Events.DESCRIPTION, menu + " 요리");
        values.put(CalendarContract.Events.CALENDAR_ID, calendarId);
        values.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());

        Uri uri = getContentResolver().insert(CalendarContract.Events.CONTENT_URI, values);
        if (uri != null) {
            Log.i("RecipeActivity", "Event added: " + uri.toString());
            Toast.makeText(this, "메뉴가 캘린더에 저장되었습니다.", Toast.LENGTH_SHORT).show();
        } else {
            Log.e("RecipeActivity", "Error adding event");
            Toast.makeText(this, "이벤트 추가 실패", Toast.LENGTH_SHORT).show();
        }
    }

    private long getPrimaryCalendarId() {
        String[] projection = new String[]{
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME
        };
        Uri uri = CalendarContract.Calendars.CONTENT_URI;
        try (Cursor cursor = getContentResolver().query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
        } catch (Exception e) {
            Log.e("RecipeActivity", "Error querying calendar", e);
        }
        return -1; // 캘린더를 찾을 수 없을 경우
    }

    private void startLoadingAnimation() {
        new Thread(() -> {
            while (isLoading) {
                handler.post(() -> {
                    progressBar.setVisibility(View.VISIBLE);
                });

                try {
                    Thread.sleep(500); // 0.5초마다 업데이트
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }).start();
    }

    private void checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR}, REQUEST_CALENDAR_PERMISSION);
        }
    }
}
